
import React, { useState } from 'react';
import { GeminiService } from './services/gemini';
import { ImagePrompt, GroundingSource } from './types';
import PromptFinder from './components/PromptFinder';

const App: React.FC = () => {
  const [gemini] = useState(() => new GeminiService());
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [foundPrompts, setFoundPrompts] = useState<ImagePrompt[]>([]);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loadingStep, setLoadingStep] = useState(0);

  const loadingMessages = [
    "Connecting to Global Nodes...",
    "Scanning Facebook & Reddit communities...",
    "Analyzing trending viral prompts...",
    "Extracting top-tier art techniques...",
    "Verifying prompt structures...",
    "Finalizing search results..."
  ];

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || isSearching) return;

    setIsSearching(true);
    setError(null);
    setFoundPrompts([]);
    
    // Cycle through loading messages for up to 15 seconds
    const interval = setInterval(() => {
      setLoadingStep(prev => (prev + 1) % loadingMessages.length);
    }, 2500);

    try {
      const result = await gemini.searchPrompts(searchQuery);
      setFoundPrompts(result.prompts);
      setSources(result.sources);
      if (result.prompts.length === 0) {
        setError("No specific prompts found for this query. Try a more general topic.");
      }
    } catch (err: any) {
      setError("The global search failed. Please try again in a moment.");
      console.error(err);
    } finally {
      clearInterval(interval);
      setIsSearching(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 flex flex-col selection:bg-blue-500/30">
      <header className="glass border-b border-white/5 px-6 py-8 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 via-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-xl shadow-blue-900/40 border border-white/10">
              <i className="fa-solid fa-earth-americas text-white text-lg animate-pulse"></i>
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-white leading-none">PromptMaster</h1>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.3em] mt-2">The Entire Web • Scanned</p>
            </div>
          </div>

          <form onSubmit={handleSearch} className="relative w-full md:w-[450px] group">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Topic (e.g. Cyberpunk Cat, 8k Portrait...)"
              className="w-full bg-slate-900/80 border border-white/10 rounded-[1.5rem] pl-6 pr-16 py-5 focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-600 text-base font-medium shadow-2xl"
            />
            <button
              type="submit"
              disabled={isSearching}
              className="absolute right-2.5 top-2.5 bottom-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl px-5 transition-all flex items-center justify-center min-w-[60px] shadow-lg shadow-blue-600/20 active:scale-95"
            >
              {isSearching ? <i className="fa-solid fa-circle-notch fa-spin"></i> : <i className="fa-solid fa-bolt"></i>}
            </button>
          </form>
        </div>
      </header>

      <main className="flex-1 max-w-4xl w-full mx-auto p-6 md:p-10 space-y-10">
        {isSearching && (
          <div className="py-20 flex flex-col items-center justify-center space-y-6 animate-in fade-in duration-300">
            <div className="relative">
              <div className="w-20 h-20 border-4 border-blue-500/10 border-t-blue-500 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center text-blue-500">
                <i className="fa-solid fa-satellite-dish text-xl"></i>
              </div>
            </div>
            <div className="text-center">
              <p className="text-blue-400 font-black uppercase tracking-widest text-xs mb-2">
                {loadingMessages[loadingStep]}
              </p>
              <p className="text-slate-500 text-[10px] font-bold">This may take up to 15 seconds to ensure quality results.</p>
            </div>
          </div>
        )}

        {error && !isSearching && (
          <div className="bg-red-500/10 border border-red-500/20 p-6 rounded-3xl text-sm text-red-400 flex items-start gap-4 animate-in fade-in slide-in-from-top-4">
            <i className="fa-solid fa-circle-exclamation mt-1"></i>
            <div>
              <p className="font-black uppercase tracking-widest text-xs mb-1">Search Interrupted</p>
              <p className="opacity-80 leading-relaxed">{error}</p>
            </div>
          </div>
        )}

        {!isSearching && foundPrompts.length === 0 && !error && (
          <div className="py-32 text-center space-y-8 animate-in fade-in zoom-in-95">
            <div className="w-32 h-32 bg-slate-900/50 rounded-[3rem] flex items-center justify-center mx-auto border border-white/5 shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-500">
              <i className="fa-solid fa-wand-sparkles text-6xl text-slate-800"></i>
            </div>
            <div className="max-w-sm mx-auto">
              <h2 className="text-2xl font-black text-white tracking-tight">Search the Entire Web</h2>
              <p className="text-slate-500 mt-4 leading-relaxed font-medium">
                Our AI scans social media, forums, and art hubs to find the exact prompt techniques used by top-tier creators.
              </p>
            </div>
          </div>
        )}

        {!isSearching && foundPrompts.length > 0 && (
          <PromptFinder
            prompts={foundPrompts}
            isLoading={isSearching}
            sources={sources}
            gemini={gemini}
          />
        )}
      </main>

      <footer className="py-12 border-t border-white/5 mt-10">
        <div className="max-w-4xl mx-auto px-6 flex flex-col items-center gap-4">
          <p className="text-[10px] font-black text-slate-700 uppercase tracking-[0.5em]">Global AI Intelligence Feed</p>
          <div className="flex items-center gap-6 opacity-20">
             <i className="fa-brands fa-facebook text-xl"></i>
             <i className="fa-brands fa-reddit text-xl"></i>
             <i className="fa-brands fa-pinterest text-xl"></i>
             <i className="fa-brands fa-discord text-xl"></i>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
