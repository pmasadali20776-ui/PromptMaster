
import { GoogleGenAI, Type } from "@google/genai";
import { ImagePrompt, GroundingSource, PromptVariation } from "../types";

export class GeminiService {
  private getClient(): GoogleGenAI {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  /**
   * Searches for high-quality prompts scanning social media and art hubs.
   * Uses Google Search grounding to find trending and viral techniques.
   */
  async searchPrompts(query: string): Promise<{ prompts: ImagePrompt[], sources: GroundingSource[] }> {
    const ai = this.getClient();
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `Perform an exhaustive deep-search across the entire internet, specifically looking at high-performing AI art communities on Facebook, Reddit (r/midjourney, r/StableDiffusion), Pinterest, Lexica, and Discord. 
      
      Topic: "${query}"

      Tasks:
      1. Find viral or top-rated prompts that people are sharing.
      2. Extract 5 unique, high-end prompt structures.
      3. For each, provide:
         - A punchy, descriptive title.
         - The full, detailed prompt including lighting, camera settings, and specific artistic styles (e.g. Octane Render, Unreal Engine 5, Cinematic).
      
      Return as JSON with a list of prompts.`,
      config: {
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 24576 }, // Higher budget for better quality search analysis
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            prompts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  prompt: { type: Type.STRING }
                },
                required: ["title", "prompt"]
              }
            }
          },
          required: ["prompts"]
        }
      },
    });

    let prompts: ImagePrompt[] = [];
    try {
      const data = JSON.parse(response.text || "{}");
      prompts = (data.prompts || []).map((p: any) => ({
        ...p,
        source: "Global Search"
      }));
    } catch (e) {
      console.error("JSON parse failed", e);
      // Minimal fallback if JSON fails
      prompts = [{ title: "Search Result", prompt: response.text || "Could not find specific prompts.", source: "Search" }];
    }

    const sources: GroundingSource[] = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || "Reference Source",
      uri: chunk.web?.uri || "#",
    })) || [];

    return { prompts, sources };
  }

  async generateImage(prompt: string): Promise<string> {
    const ai = this.getClient();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
        },
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    
    throw new Error(response.text || "Image generation failed. The prompt might be too complex or blocked by safety filters.");
  }
}
