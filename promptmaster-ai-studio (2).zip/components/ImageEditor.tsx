
import React, { useState, useEffect } from 'react';
import { GeneratedImage, ImageAdjustments, PromptVariation } from '../types';
import { GeminiService } from '../services/gemini';

interface ImageEditorProps {
  image: GeneratedImage;
  onAIEdit: (instruction: string) => void;
  isProcessing: boolean;
}

const ImageEditor: React.FC<ImageEditorProps> = ({ image, onAIEdit, isProcessing }) => {
  const [gemini] = useState(() => new GeminiService());
  const [adjustments, setAdjustments] = useState<ImageAdjustments>({
    brightness: 100,
    contrast: 100,
    saturation: 100,
  });
  const [aiInstruction, setAiInstruction] = useState(image.prompt || '');
  const [variations, setVariations] = useState<PromptVariation[]>([]);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    if (image.prompt && !image.prompt.startsWith('Source:')) {
      setAiInstruction(image.prompt);
    }
    // Clear variations when image changes to keep them relevant to the current state
    setVariations([]);
  }, [image]);

  const resetAdjustments = () => {
    setAdjustments({ brightness: 100, contrast: 100, saturation: 100 });
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (aiInstruction.trim() && !isProcessing) {
      onAIEdit(aiInstruction);
    }
  };

  const handleGetVariations = async () => {
    if (!aiInstruction.trim() || isSuggesting) return;
    setIsSuggesting(true);
    try {
      const suggestions = await gemini.suggestVariations(aiInstruction);
      setVariations(suggestions);
    } catch (err) {
      console.error("Variation suggestion failed", err);
    } finally {
      setIsSuggesting(false);
    }
  };

  const handleDownload = () => {
    setDownloading(true);
    const link = document.createElement('a');
    link.href = image.url;
    link.download = `PromptMaster-Studio-${Date.now()}.png`;
    link.click();
    
    // Simple confirmation toast effect
    setTimeout(() => setDownloading(false), 2000);
  };

  return (
    <div className="w-full h-full flex flex-col lg:flex-row gap-6 lg:gap-10">
      {/* Primary Workspace */}
      <div className="flex-1 flex flex-col gap-4">
        {/* Command Center */}
        <div className="bg-slate-900/80 border border-purple-500/30 rounded-2xl p-4 md:p-5 shadow-lg shadow-purple-900/10">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-black text-purple-400 uppercase tracking-widest flex items-center gap-2">
              <i className="fa-solid fa-terminal text-[8px]"></i>
              Workbench Command
            </span>
            <div className="flex items-center gap-3">
              {isSuggesting && <i className="fa-solid fa-wand-sparkles text-purple-400 animate-spin text-xs"></i>}
              <button 
                onClick={handleGetVariations}
                disabled={isSuggesting || isProcessing || !aiInstruction.trim()}
                className="text-[9px] font-bold text-blue-400 hover:text-white flex items-center gap-1.5 transition-colors disabled:opacity-30"
              >
                <i className="fa-solid fa-magic-wand-sparkles"></i>
                Suggest Variations
              </button>
            </div>
          </div>
          
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <textarea
              value={aiInstruction}
              onChange={(e) => setAiInstruction(e.target.value)}
              disabled={isProcessing}
              placeholder="e.g. Add glowing red eyes, remove background..."
              className="w-full bg-slate-950/50 border border-slate-800 rounded-xl p-3 text-sm md:text-base outline-none focus:ring-2 focus:ring-purple-500/50 transition-all placeholder:text-slate-700 min-h-[80px] md:min-h-[90px] resize-none text-slate-200 font-medium"
            />
            
            {/* Variation Chips */}
            {variations.length > 0 && (
              <div className="flex flex-wrap gap-2 py-1">
                {variations.map((v, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setAiInstruction(v.prompt)}
                    className="text-[10px] bg-purple-900/20 border border-purple-500/20 hover:border-purple-500/50 text-purple-300 px-3 py-1.5 rounded-lg transition-all flex items-center gap-2"
                  >
                    <i className="fa-solid fa-lightbulb text-[9px] text-purple-500"></i>
                    {v.title}
                  </button>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <button
                type="submit"
                disabled={isProcessing || !aiInstruction.trim()}
                className="flex-1 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded-xl py-3 text-sm font-bold transition-all shadow-lg flex items-center justify-center gap-3 active:scale-[0.98]"
              >
                {isProcessing ? (
                  <i className="fa-solid fa-spinner fa-spin"></i>
                ) : (
                  <i className="fa-solid fa-wand-magic-sparkles"></i>
                )}
                <span>Update Image</span>
              </button>
              <button
                type="button"
                onClick={() => { setAiInstruction(''); setVariations([]); }}
                className="px-4 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl transition-all border border-white/5"
                title="Clear"
              >
                <i className="fa-solid fa-rotate-left"></i>
              </button>
            </div>
          </form>
        </div>

        {/* Image Preview Area */}
        <div className="relative group rounded-2xl overflow-hidden shadow-2xl bg-black/40 flex items-center justify-center min-h-[280px] md:min-h-[400px] border border-white/5">
          <img
            src={image.url}
            alt="AI Output"
            className="max-w-full max-h-[400px] md:max-h-[500px] object-contain transition-all duration-700 ease-out"
            style={{
              filter: `brightness(${adjustments.brightness}%) contrast(${adjustments.contrast}%) saturate(${adjustments.saturation}%)`
            }}
          />
          
          {/* Action Overlay */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <button 
              onClick={handleDownload}
              className={`w-10 h-10 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-white/10 shadow-xl transition-all ${downloading ? 'bg-green-600 scale-110' : 'bg-slate-900/80 hover:bg-blue-600'}`}
              title="Download Artwork"
            >
              {downloading ? <i className="fa-solid fa-check"></i> : <i className="fa-solid fa-download"></i>}
            </button>
          </div>

          {downloading && (
            <div className="absolute bottom-4 bg-green-600/90 backdrop-blur text-white text-[10px] font-bold px-4 py-2 rounded-full shadow-lg animate-bounce">
              Download Started!
            </div>
          )}
        </div>
      </div>

      {/* Control Sidebar */}
      <div className="w-full lg:w-64 space-y-6 bg-slate-900/40 p-5 rounded-2xl border border-white/5 backdrop-blur-sm shrink-0">
        <div>
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Post-Processing</h3>
            <button onClick={resetAdjustments} className="text-[10px] font-bold text-blue-400 hover:text-white transition-colors">Reset</button>
          </div>
          
          <div className="space-y-6">
            <ControlSlider label="Exposure" icon="fa-brightness" value={adjustments.brightness} onChange={(val) => setAdjustments({ ...adjustments, brightness: val })} min={0} max={200} />
            <ControlSlider label="Contrast" icon="fa-circle-half-stroke" value={adjustments.contrast} onChange={(val) => setAdjustments({ ...adjustments, contrast: val })} min={0} max={200} />
            <ControlSlider label="Saturation" icon="fa-droplet" value={adjustments.saturation} onChange={(val) => setAdjustments({ ...adjustments, saturation: val })} min={0} max={200} />
          </div>
        </div>

        <div className="pt-4 space-y-4">
           <div className="p-3 bg-slate-800/50 rounded-xl border border-white/5">
             <h4 className="text-[9px] font-black text-slate-500 uppercase mb-2">Editor Notes</h4>
             <p className="text-[10px] text-slate-400 leading-relaxed italic">
               "Editing images iteratively preserves structural elements while updating specific details based on your text."
             </p>
           </div>
        </div>
      </div>
    </div>
  );
};

const ControlSlider: React.FC<{ label: string; icon: string; value: number; onChange: (val: number) => void; min: number; max: number }> = ({ label, icon, value, onChange, min, max }) => (
  <div className="space-y-2">
    <div className="flex justify-between items-center px-1">
      <span className="text-[10px] font-bold text-slate-500 flex items-center gap-2 uppercase">
        <i className={`fa-solid ${icon} text-slate-700`}></i>
        {label}
      </span>
      <span className="text-[10px] text-blue-400 font-mono">{value}%</span>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      value={value}
      onChange={(e) => onChange(parseInt(e.target.value))}
      className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-blue-500"
    />
  </div>
);

export default ImageEditor;
