
import React, { useState } from 'react';
import { ImagePrompt, GroundingSource } from '../types';
import { GeminiService } from '../services/gemini';

interface PromptFinderProps {
  prompts: ImagePrompt[];
  isLoading: boolean;
  sources: GroundingSource[];
  gemini: GeminiService;
}

const PromptFinder: React.FC<PromptFinderProps> = ({ prompts, isLoading, sources, gemini }) => {
  if (isLoading) {
    return (
      <div className="space-y-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="animate-pulse bg-slate-900/40 border border-white/5 rounded-3xl p-6 space-y-4">
            <div className="h-4 bg-slate-800 rounded w-1/4"></div>
            <div className="h-20 bg-slate-800 rounded w-full"></div>
            <div className="flex gap-3">
              <div className="h-10 bg-slate-800 rounded flex-1"></div>
              <div className="h-10 bg-slate-800 rounded flex-1"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {prompts.map((p, idx) => (
        <PromptCard key={idx} prompt={p} gemini={gemini} />
      ))}

      {sources.length > 0 && (
        <div className="pt-8 border-t border-white/5">
          <h3 className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-4 flex items-center gap-2">
            <i className="fa-solid fa-link"></i> Web Context Sources
          </h3>
          <div className="flex flex-wrap gap-2">
            {sources.map((s, idx) => (
              <a
                key={idx}
                href={s.uri}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] bg-slate-900/50 border border-white/5 px-3 py-2 rounded-xl text-slate-500 hover:text-blue-400 hover:border-blue-500/30 transition-all"
              >
                {s.title}
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const PromptCard: React.FC<{ prompt: ImagePrompt; gemini: GeminiService }> = ({ prompt, gemini }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [copyStatus, setCopyStatus] = useState<'idle' | 'copied'>('idle');
  const [error, setError] = useState<string | null>(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(prompt.prompt);
    setCopyStatus('copied');
    setTimeout(() => setCopyStatus('idle'), 2000);
  };

  const handleMake = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const base64 = await gemini.generateImage(prompt.prompt);
      setGeneratedImage(base64);
    } catch (err: any) {
      setError(err.message || "Failed to generate image.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-slate-900/40 border border-white/5 rounded-[2rem] p-6 md:p-8 transition-all hover:bg-slate-900/60 group">
      <div className="flex flex-col gap-6">
        <div>
          <h4 className="text-lg font-bold text-white mb-3 group-hover:text-blue-400 transition-colors">
            {prompt.title}
          </h4>
          <div className="relative">
            <div className="bg-slate-950/50 border border-white/5 rounded-2xl p-5 text-sm text-slate-400 leading-relaxed font-mono italic">
              {prompt.prompt}
            </div>
          </div>
        </div>

        {error && (
          <div className="text-[10px] text-red-400 font-bold uppercase flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation"></i>
            {error}
          </div>
        )}

        <div className="flex flex-wrap gap-3">
          <button
            onClick={handleCopy}
            className={`flex-1 min-w-[140px] py-4 rounded-2xl text-xs font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 border ${
              copyStatus === 'copied' 
                ? 'bg-green-600/10 border-green-500/30 text-green-400' 
                : 'bg-slate-800/50 border-white/5 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <i className={`fa-solid ${copyStatus === 'copied' ? 'fa-check' : 'fa-copy'}`}></i>
            {copyStatus === 'copied' ? 'Prompt Copied' : 'Copy Prompt'}
          </button>

          <button
            onClick={handleMake}
            disabled={isGenerating}
            className="flex-1 min-w-[140px] py-4 rounded-2xl text-xs font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/20 disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <i className="fa-solid fa-circle-notch fa-spin"></i>
                Generating...
              </>
            ) : (
              <>
                <i className="fa-solid fa-wand-magic-sparkles"></i>
                Make From App
              </>
            )}
          </button>
        </div>

        {generatedImage && (
          <div className="mt-4 animate-in zoom-in-95 fade-in duration-500">
            <div className="relative rounded-[1.5rem] overflow-hidden border border-white/10 group/img">
              <img src={generatedImage} alt="AI Result" className="w-full aspect-square object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover/img:opacity-100 transition-opacity flex items-end p-6">
                <a 
                  href={generatedImage} 
                  download={`promptmaster-${Date.now()}.png`}
                  className="bg-white text-black text-[10px] font-black uppercase px-4 py-2 rounded-lg"
                >
                  Download HD
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PromptFinder;
