
export interface ImagePrompt {
  title: string;
  prompt: string;
  source: string;
}

export interface PromptVariation {
  title: string;
  prompt: string;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface GeneratedImage {
  url: string;
  base64: string;
  prompt: string;
}

export interface ImageAdjustments {
  brightness: number;
  contrast: number;
  saturation: number;
}
